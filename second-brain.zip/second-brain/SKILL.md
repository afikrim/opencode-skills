---
name: second-brain
description: Maintains the user's personal Obsidian "second brain" vault at ~/Documents/Volta/volta — a permalinked, atomic-note knowledge base split into 4 segments (Personal, Work, Career, Goals), with topic subfolders inside Personal, a codebase-wiki inside Work for per-repo problem/fix notes, kind-based subfolders inside Career, and thin goal-tracker notes in Goals that link out to evidence rather than duplicating it. Actively tracks the user's goal to reach senior engineer level. Two things run continuously in the background of every session, not just when explicitly asked about notes: (1) the main thread consults the vault before its very first reply in a new session, so it answers with the user's own history in mind; (2) filing a durable, reusable fact that came out of a reply — a decision, a bug and its fix, something learned, career-relevant progress, a life/personal detail worth keeping — is fully automatic via a Stop hook that judges and files in a detached background process, with nothing for the main thread to do. Also use this skill explicitly whenever the user asks to save/remember something (spawn `second-brain-recap` yourself, synchronously), asks what they know about a topic, asks about their career progress toward senior, or asks to search/query/browse their notes or vault. Only the main thread does the session-start lookup; subagents (and the background Stop-hook filer) never do it, so nothing here ever nests.
---

# Second Brain (Obsidian vault)

You maintain the user's personal knowledge base: a folder of small, linked Markdown
notes at `~/Documents/Volta/volta`, structured for two things — (1) never having to
re-explain the same fact to you twice, and (2) being able to look back in six months
and see concrete evidence of the climb to senior engineer, not vague memories of it.

Full structure, frontmatter schema, and querying conventions are in
`references/vault-structure.md` — read it before creating your first note in a
session, or whenever you're unsure which segment/folder something belongs in.
Always create notes with `scripts/new_note.py` (see its `--help`); it enforces the
naming and frontmatter conventions so you don't have to compute them by hand.
It also handles folder linking for you: Obsidian can't link to a folder, only a
file, so every folder gets a same-named index note inside it, and every note
(including the index notes themselves) gets a `Parent: [[...]]` line up to
`Welcome.md` — created automatically, never something you write by hand.

## The two automatic behaviors

### 1. Before your first reply in a new session (main thread only)

Before composing your first reply of the session, run
`scripts/query_vault.py --text "<keyword>"` (and `--project`/`--repo`/`--tag`
if a name is obvious from what the user just said) for anything relevant to
their message. Read only the notes that actually surface — this is a targeted
query, not a blanket read of the vault, so don't grep broadly or skim whole
segments "just in case." Let what you find inform your answer — e.g. if they
mention a repo you have a codebase-wiki entry for, or ask something you
already have a Career note about. If nothing matches, that's a normal result;
don't go looking further.

Don't do this on every later turn in the session — once you've loaded relevant
context at the start, you already have it. Re-check mid-session only if the
conversation moves to a clearly different topic you haven't looked up yet.
**Skip entirely if you are running as a subagent** — a subagent was given an
explicit, self-contained brief by whoever spawned it; it doesn't need vault
context.

### 2. After a reply that produced something worth keeping (fully automatic, off the main thread)

This no longer needs the main thread to do anything. A `Stop` hook
(`~/.claude/settings.json`, running `scripts/stop_hook.py`) fires after every
assistant reply, reads the last exchange straight off the hook payload, and
launches a fully detached, headless `claude -p --agent second-brain-stop-filer`
process with it — the main thread never sees this happen, never blocks on it,
and never has to judge or spawn anything itself. That headless agent applies
the same qualifying bar this section used to describe inline (a bug and its
fix, a decision, a project fact, a status change, a personal/life detail, or
evidence toward the senior goal — never small talk, general-knowledge answers,
or vague not-sure-which-segment content), and only files a note when something
actually clears it, using the same query-first/one-fact-per-note/supersede
workflow as `second-brain-recap`.

Two things make this safe to run unattended, both already wired into
`stop_hook.py` — know about them before touching that script:
- **Recursion guard**: the headless filer is itself a full session and would
  otherwise trigger its own Stop hook on its own reply, forever. A
  `SECOND_BRAIN_STOP_FILER_ACTIVE=1` env var is set on the spawned process and
  propagates to anything it forks; the hook no-ops immediately whenever it's
  set.
- **Pre-approved tool calls**: there's no human present to answer a permission
  prompt in a detached process, so `query_vault.py`/`new_note.py` are
  pre-approved via `--allowedTools`, matched on the literal `~/.claude/...`
  path form the agent actually writes (not the shell-expanded absolute path —
  they silently don't match otherwise).

You (the main thread) don't need to do anything for this passive case anymore.
The only time you should still spawn `second-brain-recap` yourself, inline, is
the **explicit** case below.

### Explicit ask ("remember this", "what do you know about X")

When the user directly asks you to save/remember something, spawn the
**`second-brain-recap`** agent (`subagent_type: "second-brain-recap"`)
yourself, synchronously — this is a real, immediate request, not passive
housekeeping, so it's fine for it to be visible in-thread. Brief it with just
the distilled fact(s) — one fact per note, not a conversation transcript —
since it has no memory of this conversation:

```
File the following into the second-brain vault:

<the specific fact(s) to capture, already distilled to one fact per note>
```

Multiple unrelated facts in one ask → one agent call, multiple notes — don't
split into several agent calls for one recap.

## Querying the vault

Two equivalent ways to answer "what do I know about X" — pick whichever fits:

- **`scripts/query_vault.py`** (works whether or not Obsidian is open) — filters by
  `--segment`, `--tag`, `--project`, `--repo`, `--area`, `--type`, full-text via
  `--text`, or `--backlinks-to <id>` to see everything linking to a given note
  (e.g. every piece of evidence toward the senior goal). Run it directly in the
  main thread for a read-only lookup — it's cheap, no subagent needed. It prints
  one line per match (path, title, first line) so you can decide which notes are
  worth reading in full before answering. Add `--kind note` to hide folder-index
  notes from a content search, or `--kind index` to browse just the structure.
- **The `obsidian-cli` skill** — if Obsidian happens to be open, `obsidian search`,
  `obsidian tags`, and `obsidian backlinks` do the same job against the live app.
  Either path reads the same files; use whichever is already convenient.

For a synthesized answer, read the full body of whatever query_vault.py surfaces
(notes are short by design) and answer from those — don't just dump the raw
matches at the user unless they asked for a list.

## Revising a decision — never overwrite

The vault's permalink scheme exists precisely so a note is a stable historical
record, not a living document — so once a note states a fact or a decision,
don't edit that fact in place, even when it turns out to be wrong. Instead:

```
new_note.py ... --supersedes <old-id-or-slug> --reason "<why the old decision changed>"
```

This creates the new note as normal, adds a `supersedes:`/`Supersedes: [[...]]`
pointer to it, and patches the OLD note with a `superseded_by:` pointer —
**the old note's original content is never touched**. The result: open the old
note and you see it was superseded and why; open the new one and you see what
it replaced. `query_vault.py --exclude-superseded` hides stale notes from normal
lookups without deleting them, and plain `git log -p <path>` inside the vault
gives a full diff history of any note as a second, independent safety net.

The one exception is `03-Goals/` tracker notes: their `Status:`/target fields are
current-state, not historical claims, so editing those in place is expected — a
goal note's job is to always show where things stand *now*. Reserve --supersedes
for facts and decisions living in Personal/Work/Career.

## Bootstrapping a new area

The first time a project, repo, or goal comes up, its folder doesn't exist yet —
that's fine, `new_note.py` creates it. There's no setup step required beyond
picking the right `--segment` (and `--project`/`--repo` for work notes).
