#!/usr/bin/env python3
"""Create one atomic note in the second-brain vault.

Enforces the vault's conventions so every note (however it gets created —
main-thread, recap subagent, or the user by hand) ends up in the same shape:
a timestamp-ID filename that never changes (the permalink), frontmatter with
a stable schema, and a short body.

Usage:
    new_note.py --segment work --project payments-api \\
        --title "Docker healthcheck timeout on staging" \\
        --tags docker,timeout \\
        --body "Healthcheck was timing out at 5s under load.\\nFix: raised to 15s in docker-compose.yml." \\
        --links 202608301090-staging-env-vars

Segments: personal, work, career, goals
  --area NAME      only with --segment personal: files under 00-Personal/<area>/
                   (any name works, but Health/Relationships/Home-Finance/Hobbies/Travel
                   are the established vocabulary — see references/vault-structure.md)
  --project NAME   only with --segment work: files under 01-Work/<project>/
  --repo NAME      only with --segment work: files under 01-Work/codebase-wiki/<repo>/
                   (--project and --repo are mutually exclusive)
  --type {skill,feedback,learning}
                   only with --segment career: files under 02-Career/<skills|feedback|learning-log>/
  --segment goals notes are always flat under 03-Goals/ (no subfolder flag) —
                   goals notes must stay thin: target + status + links out to evidence
                   elsewhere, never the evidence itself.

Revising a decision (never overwrite):
  --supersedes ID-SLUG   the id-slug (or bare numeric id) of an existing note this
                         one revises. The OLD note's content is never touched — it
                         only gets a `superseded_by:` pointer added to its frontmatter.
                         The new note gets a matching `supersedes:` pointer plus a
                         "Supersedes: [[...]]" line in its body. Use --reason to record
                         why, so the old (wrong) decision and the correction are both
                         visible and linked, instead of one silently replacing the other.

If the vault is a git repo (it is, by default), every run of this script also commits
the change — so even outside the supersede convention, `git log -p <file>` gives a
full diff history of any note.

Folder linking: Obsidian can't link to a folder, only to a file. So every folder gets
a `<folder-name>.md` index note living inside it — this script creates any missing
ones automatically, all the way up to the vault root (whose index is `Welcome.md`).
Every note this script creates gets a `Parent: [[...]]` line pointing at its
containing folder's index, and every folder index has its own `Parent:` line
pointing at ITS parent's index — so following Parent links from any note always
reaches Welcome.md eventually.

Prints the created path and the wikilink target to use from other notes.
"""
import argparse
import datetime
import pathlib
import re
import subprocess
import sys

VAULT = pathlib.Path.home() / "Documents" / "Volta" / "volta"

SEGMENT_DIRS = {
    "personal": "00-Personal",
    "work": "01-Work",
    "career": "02-Career",
    "goals": "03-Goals",
}

CAREER_TYPE_DIRS = {
    "skill": "skills",
    "feedback": "feedback",
    "learning": "learning-log",
}

MAX_BODY_LINES = 10


def yaml_str(value: str) -> str:
    """Render free text as a safe YAML frontmatter scalar. Quote+escape it
    whenever the raw form would be ambiguous -- most commonly a colon, which
    YAML reads as a mapping separator anywhere it's followed by a space (or
    ends the line), even inside what's meant to be plain text like a title."""
    needs_quoting = (
        value == ""
        or re.search(r":(\s|$)", value)
        or value[0] in "-?:,[]{}#&*!|>'\"%@`"
        or value != value.strip()
        or value.lower() in {"true", "false", "null", "~", "yes", "no"}
    )
    if not needs_quoting:
        return value
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")[:60] or "note"


def display_name(folder_name: str) -> str:
    """Strip a leading numeric sort-prefix like '00-' for a friendly link alias."""
    return re.sub(r"^\d+-", "", folder_name)


def rel_link(path: pathlib.Path) -> str:
    """Vault-relative path (no .md), for path-qualified links that never collide
    even when two folders happen to share a name (e.g. a project and a
    same-named codebase-wiki repo folder)."""
    return path.relative_to(VAULT).with_suffix("").as_posix()


def ensure_folder_index(folder: pathlib.Path) -> pathlib.Path:
    """Make sure folder/<folder-name>.md exists, recursively creating every
    ancestor's index too, up to Welcome.md at the vault root. Returns the path
    to folder's own index note."""
    folder.mkdir(parents=True, exist_ok=True)
    index_path = folder / f"{folder.name}.md"
    if index_path.exists():
        return index_path

    parent_folder = folder.parent
    if parent_folder == VAULT:
        parent_ref, parent_display = "Welcome", "Second Brain Home"
    else:
        parent_index = ensure_folder_index(parent_folder)
        parent_ref, parent_display = rel_link(parent_index), display_name(parent_folder.name)

    content = (
        "---\n"
        f"title: {yaml_str(display_name(folder.name))}\n"
        "kind: index\n"
        f"created: {datetime.date.today().isoformat()}\n"
        "---\n\n"
        f"Parent: [[{parent_ref}|{parent_display}]]\n"
    )
    index_path.write_text(content)
    return index_path


def find_note(vault: pathlib.Path, ref: str) -> pathlib.Path:
    ref = ref.strip()
    matches = list(vault.rglob(f"{ref}.md"))
    if not matches and ref.isdigit():
        matches = [p for p in vault.rglob("*.md") if p.stem.startswith(ref)]
    if not matches:
        sys.exit(f"error: --supersedes reference '{ref}' matched no note in the vault")
    if len(matches) > 1:
        sys.exit(f"error: --supersedes reference '{ref}' is ambiguous: {[str(m) for m in matches]}")
    return matches[0]


def add_frontmatter_field(path: pathlib.Path, field: str, value: str) -> None:
    lines = path.read_text().split("\n")
    if not lines or lines[0].strip() != "---":
        sys.exit(f"error: {path} has no frontmatter block, can't patch it")
    end = lines.index("---", 1)
    for line in lines[1:end]:
        if line.startswith(f"{field}:"):
            sys.exit(
                f"error: {path} already has '{line.strip()}' — it looks already "
                f"superseded. Resolve manually if this second revision is intentional."
            )
    lines.insert(end, f"{field}: {value}")
    path.write_text("\n".join(lines))


def git_commit(vault: pathlib.Path, message: str) -> None:
    if not (vault / ".git").is_dir():
        return
    subprocess.run(["git", "-C", str(vault), "add", "-A"], capture_output=True)
    result = subprocess.run(["git", "-C", str(vault), "commit", "-q", "-m", message], capture_output=True, text=True)
    if result.returncode != 0 and "nothing to commit" not in (result.stdout + result.stderr):
        print(f"warning: git commit failed: {(result.stdout + result.stderr).strip()}", file=sys.stderr)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--segment", required=True, choices=sorted(SEGMENT_DIRS))
    p.add_argument("--area", help="personal only: subfolder under 00-Personal/<area>/")
    p.add_argument("--project", help="work only: subfolder under 01-Work/<project>/")
    p.add_argument("--repo", help="work only: subfolder under 01-Work/codebase-wiki/<repo>/")
    p.add_argument("--type", choices=sorted(CAREER_TYPE_DIRS), help="career only: skill, feedback, or learning")
    p.add_argument("--title", required=True)
    p.add_argument("--tags", default="", help="comma-separated, no #")
    p.add_argument("--body", required=True, help="note body; use \\n for newlines")
    p.add_argument("--links", default="", help="comma-separated existing note filenames (no .md) for a Related line")
    p.add_argument("--aliases", default="", help="comma-separated alternate titles")
    p.add_argument("--supersedes", help="id-slug (or bare id) of an existing note this one revises")
    p.add_argument("--reason", default="", help="with --supersedes: why the old decision was revised")
    args = p.parse_args()

    if args.project and args.repo:
        p.error("--project and --repo are mutually exclusive")
    if (args.project or args.repo) and args.segment != "work":
        p.error("--project/--repo only apply when --segment work")
    if args.area and args.segment != "personal":
        p.error("--area only applies when --segment personal")
    if args.type and args.segment != "career":
        p.error("--type only applies when --segment career")
    if args.reason and not args.supersedes:
        p.error("--reason only applies with --supersedes")

    old_path = find_note(VAULT, args.supersedes) if args.supersedes else None

    now = datetime.datetime.now()
    note_id = now.strftime("%Y%m%d%H%M")
    slug = slugify(args.title)
    filename = f"{note_id}-{slug}.md"

    base = VAULT / SEGMENT_DIRS[args.segment]
    if args.repo:
        base = base / "codebase-wiki" / slugify(args.repo)
    elif args.project:
        base = base / slugify(args.project)
    elif args.area:
        base = base / args.area
    elif args.type:
        base = base / CAREER_TYPE_DIRS[args.type]
    folder_index = ensure_folder_index(base)

    path = base / filename
    if path.exists():
        sys.exit(f"error: {path} already exists (two notes in the same minute? wait a moment and retry)")

    tags = [t.strip() for t in args.tags.split(",") if t.strip()]
    aliases = [a.strip() for a in args.aliases.split(",") if a.strip()]

    front = [
        "---",
        f"id: {note_id}",
        f"title: {yaml_str(args.title)}",
    ]
    if aliases:
        front.append(f"aliases: [{', '.join(yaml_str(a) for a in aliases)}]")
    front.append(f"segment: {args.segment}")
    if args.repo:
        front.append(f"repo: {yaml_str(args.repo)}")
    elif args.project:
        front.append(f"project: {yaml_str(args.project)}")
    elif args.area:
        front.append(f"area: {yaml_str(args.area)}")
    elif args.type:
        front.append(f"type: {args.type}")
    if old_path:
        front.append(f"supersedes: {old_path.stem}")
    front.append(f"tags: [{', '.join(yaml_str(t) for t in tags)}]")
    front.append(f"created: {now.strftime('%Y-%m-%d')}")
    front.append("---")

    body_text = args.body.replace("\\n", "\n").strip()
    body_lines = [l for l in body_text.split("\n") if l.strip()]

    content = "\n".join(front) + "\n\n" + body_text + "\n"

    if args.links:
        links = [l.strip() for l in args.links.split(",") if l.strip()]
        content += "\nRelated: " + ", ".join(f"[[{l}]]" for l in links) + "\n"

    if old_path:
        content += f"\nSupersedes: [[{old_path.stem}]]"
        if args.reason:
            content += f"\nReason: {args.reason}"
        content += "\n"

    content += f"\nParent: [[{rel_link(folder_index)}|{display_name(base.name)}]]\n"

    path.write_text(content)

    link_target = f"{note_id}-{slug}"

    if old_path:
        add_frontmatter_field(old_path, "superseded_by", link_target)
        git_commit(VAULT, f"Supersede {old_path.stem} -> {link_target}: {args.title}")
        print(f"Superseded: {old_path} (added superseded_by pointer, content untouched)")
    else:
        git_commit(VAULT, f"Add note: {args.title}")

    print(f"Created: {path}")
    print(f"Link target: [[{link_target}]]")
    if len(body_lines) > MAX_BODY_LINES:
        print(
            f"WARNING: body has {len(body_lines)} lines (>{MAX_BODY_LINES}). "
            "This note is doing too much — consider splitting it into separate atomic notes.",
            file=sys.stderr,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
