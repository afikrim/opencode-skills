#!/usr/bin/env python3
"""Query the second-brain vault. Filters combine with AND; omit all filters to list everything.

Examples:
    query_vault.py --segment career --type skill
    query_vault.py --tag docker
    query_vault.py --repo payments-api
    query_vault.py --backlinks-to 202609070936-reach-senior-engineer-level   # notes linking to the goal
    query_vault.py --text "healthcheck"
    query_vault.py --segment goals --exclude-superseded                      # only still-current trackers
    query_vault.py --kind note                                               # hide folder-index/navigation notes

Prints, per match: relative path, title, first content line, and a
SUPERSEDED-by flag when applicable — enough to decide whether to open the
full note, without dumping every file.
"""
import argparse
import pathlib
import re
import sys

VAULT = pathlib.Path.home() / "Documents" / "Volta" / "volta"


def unquote_scalar(value: str) -> str:
    """Undo yaml_str() from new_note.py: strip a matching pair of double quotes
    and unescape \\" / \\\\ -- values that were never quoted pass through as-is."""
    value = value.strip()
    if len(value) >= 2 and value.startswith('"') and value.endswith('"'):
        value = value[1:-1].replace('\\"', '"').replace("\\\\", "\\")
    return value


def parse_frontmatter(text: str):
    lines = text.split("\n")
    if not lines or lines[0].strip() != "---":
        return {}, text
    try:
        end = lines.index("---", 1)
    except ValueError:
        return {}, text
    fm = {}
    for line in lines[1:end]:
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key, value = key.strip(), value.strip()
        if value.startswith("[") and value.endswith("]"):
            fm[key] = [unquote_scalar(v) for v in value[1:-1].split(",") if v.strip()]
        else:
            fm[key] = unquote_scalar(value)
    body = "\n".join(lines[end + 1:]).strip()
    return fm, body


def resolve_ref(ref: str) -> str:
    """Best-effort resolve a --backlinks-to ref to the note's filename stem."""
    ref = ref.strip()
    candidates = list(VAULT.rglob(f"{ref}.md"))
    if not candidates and ref.isdigit():
        candidates = [p for p in VAULT.rglob("*.md") if p.stem.startswith(ref)]
    return candidates[0].stem if candidates else ref


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--segment", choices=["personal", "work", "career", "goals"])
    p.add_argument("--tag")
    p.add_argument("--project")
    p.add_argument("--repo")
    p.add_argument("--area")
    p.add_argument("--type", choices=["skill", "feedback", "learning"])
    p.add_argument("--backlinks-to", help="id-slug (or bare id) of a note; finds notes linking to it")
    p.add_argument("--text", help="case-insensitive substring match over the whole note")
    p.add_argument("--exclude-superseded", action="store_true", help="hide notes that have a superseded_by pointer")
    p.add_argument("--kind", choices=["note", "index"], help="'note' hides folder-index notes, 'index' shows only them")
    args = p.parse_args()

    backlink_re = re.compile(re.escape(f"[[{resolve_ref(args.backlinks_to)}")) if args.backlinks_to else None

    results = []
    for path in sorted(VAULT.rglob("*.md")):
        if ".obsidian" in path.parts:
            continue
        text = path.read_text()
        fm, body = parse_frontmatter(text)

        if args.segment and fm.get("segment") != args.segment:
            continue
        if args.project and fm.get("project") != args.project:
            continue
        if args.repo and fm.get("repo") != args.repo:
            continue
        if args.area and fm.get("area") != args.area:
            continue
        if args.type and fm.get("type") != args.type:
            continue
        if args.tag and args.tag not in fm.get("tags", []):
            continue
        if args.exclude_superseded and fm.get("superseded_by"):
            continue
        is_index = fm.get("kind") == "index"
        if args.kind == "note" and is_index:
            continue
        if args.kind == "index" and not is_index:
            continue
        if backlink_re and not backlink_re.search(text):
            continue
        if args.text and args.text.lower() not in text.lower():
            continue

        results.append((path, fm, body))

    if not results:
        print("No notes matched.")
        return 0

    for path, fm, body in results:
        rel = path.relative_to(VAULT)
        title = fm.get("title", path.stem)
        first_line = next(
            (
                l
                for l in body.split("\n")
                if l.strip() and not l.startswith(("Related:", "Supersedes:", "Reason:", "Parent:"))
            ),
            "",
        )
        flag = f"  [SUPERSEDED by [[{fm['superseded_by']}]]]" if fm.get("superseded_by") else ""
        print(f"{rel}{flag}\n  {title}\n  {first_line}\n")

    print(f"{len(results)} note(s) matched.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
